﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLSinhVien
{
    public partial class Form1 : Form
    {
        private QLSVEntities dbContext;
        //private DataTable table;
        public Form1()
        {
            InitializeComponent();
            dbContext = new QLSVEntities();

            //table = new DataTable();
            //table.Columns.Add("SV_ID", typeof(int));
            //table.Columns.Add("SV_Name", typeof(string));
            //table.Columns.Add("SV_Phone", typeof(string));
            //table.Columns.Add("SV_Email", typeof(string));
        }

        private void RefreshView()
        {
            try
            {
                //var rows = dbContext.SinhViens.ToList(); // Dùng nếu muốn chọn những cột sẽ hiển thị ra

                //table.Rows.Clear();

                //foreach (var row in rows)
                //{
                //    table.Rows.Add(row.SV_ID, row.SV_Name, row.SV_Email);
                //}

                dgvSV.DataSource = dbContext.SinhViens.ToList();

                int dgvWidth = dgvSV.Width;
                dgvSV.Columns["SV_ID"].Width = (int)(dgvWidth * 0.05);
                dgvSV.Columns["SV_Name"].Width = (int)(dgvWidth * 0.3);
                dgvSV.Columns["SV_Phone"].Width = (int)(dgvWidth * 0.2);
                dgvSV.Columns["SV_Email"].Width = (int)(dgvWidth * 0.45);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private void btAdd_Click(object sender, EventArgs e)
        {
            if (txtEmail.Text != "" && txtName.Text != "" && txtPhone.Text != "")
            {
                SinhVien sv = new SinhVien
                {
                    SV_Name = txtName.Text,
                    SV_Email = txtEmail.Text,
                    SV_Phone = txtPhone.Text
                };

                dbContext.SinhViens.Add(sv);
                
                try
                {
                    int rowAffected = dbContext.SaveChanges();
                    if (rowAffected > 0)
                    {
                        MessageBox.Show("Thêm thành công!");
                        txtName.Text = "";
                        txtPhone.Text = "";
                        txtEmail.Text = "";
                        RefreshView();
                    }
                    else
                    {
                        MessageBox.Show("Thêm không thành công!");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin!");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            RefreshView();
        }

        private void dgvSV_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            DataGridViewRow row = dgvSV.SelectedRows[0];

            txtName.Text = row.Cells[1].Value.ToString();
            txtPhone.Text = row.Cells[2].Value.ToString();
            txtEmail.Text = row.Cells[3].Value.ToString();
        }

        private void btEdit_Click(object sender, EventArgs e)
        {
            if (dgvSV.SelectedRows.Count > 0)
            {
                if (txtEmail.Text != "" && txtName.Text != "" && txtPhone.Text != "")
                {
                    DataGridViewRow row = dgvSV.SelectedRows[0];
                    int ID = Convert.ToInt16(row.Cells[0].Value.ToString());

                    var sv = dbContext.SinhViens.Find(ID);

                    sv.SV_Name = txtName.Text;
                    sv.SV_Phone = txtPhone.Text;
                    sv.SV_Email = txtEmail.Text;

                    try
                    {
                        int rowAffected = dbContext.SaveChanges();
                        if (rowAffected > 0)
                        {
                            MessageBox.Show("Sửa thành công!");
                            
                            RefreshView();
                        }
                        else
                        {
                            MessageBox.Show("Sửa không thành công!");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Lỗi: " + ex.Message);
                    }
                }
                else
                {
                    MessageBox.Show("Vui lòng nhập đầy đủ thông tin!");
                }
            }
            else
            {
                MessageBox.Show("Chọn dòng muốn sửa!");
            }
        }

        private void btDelete_Click(object sender, EventArgs e)
        {
            if (dgvSV.SelectedRows.Count > 0)
            {
                DataGridViewRow row = dgvSV.SelectedRows[0];
                int ID = Convert.ToInt16(row.Cells[0].Value.ToString());

                var sv = dbContext.SinhViens.Find(ID);

                dbContext.SinhViens.Remove(sv);

                try
                {
                    int rowAffected = dbContext.SaveChanges();
                    if (rowAffected > 0)
                    {
                        MessageBox.Show("Xóa thành công!");

                        RefreshView();
                    }
                    else
                    {
                        MessageBox.Show("Xóa không thành công!");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Chọn dòng muốn xóa!");
            }
        }

        private void btExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btSearch_Click(object sender, EventArgs e)
        {
            if (txtKeyword.Text != "")
            {
                try
                {
                    //var searchResult = dbContext.SinhViens.Where(sv => sv.SV_Name.ToLower().Contains(txtKeyword.Text.ToLower())).ToList();

                    //table.Rows.Clear();

                    //foreach (var row in searchResult)
                    //{
                    //    table.Rows.Add(row.SV_ID, row.SV_Name, row.SV_Phone, row.SV_Email);
                    //}

                    dgvSV.DataSource = dbContext.SinhViens.Where(sv => sv.SV_Name.ToLower().Contains(txtKeyword.Text.ToLower())).ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Nhập tên sinh viên muốn tìm!");
            }
        }

        private void btReset_Click(object sender, EventArgs e)
        {
            RefreshView();
        }
    }
}
