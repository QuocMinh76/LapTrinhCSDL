﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using DTO_QuanLy;

namespace DAL_QuanLy
{
    public class DAL_SinhVien : DBConnect
    {
        ///<summary>
        /// Get toàn bộ sinh viên
        ///</summary>
        ///<returns></returns>
        
        public DataTable getSinhVien()
        {
            SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM SINHVIEN", _conn);
            DataTable dtSinhVien = new DataTable();
            da.Fill(dtSinhVien);
            return dtSinhVien;
        }

        ///<summary>
        /// Thêm sinh viên
        ///</summary>
        ///<param name="tv"></param>
        ///<returns></returns>
        
        public bool themSinhVien(DTO_SinhVien sv)
        {
            try
            {
                // Kết nối
                _conn.Open();
                // Query string - vì SV_ID là identity (giá trị tự tăng dần) nên không cần phải insert ID
                string SQL = string.Format("INSERT INTO SINHVIEN(SV_NAME, SV_PHONE, SV_EMAIL) VALUES(N'{0}', '{1}', '{2}')", sv.SINHVIEN_NAME, sv.SINHVIEN_PHONE, sv.SINHVIEN_EMAIL);

                SqlCommand cmd = new SqlCommand(SQL, _conn);
                // Query và kiểm tra
                if (cmd.ExecuteNonQuery() > 0)
                    return true;
            }
            catch (Exception e)
            {

            }
            finally
            {
                // Đóng kết nối
                _conn.Close();
            }
            
            return false;
        }

        /// <summary>
        /// Sửa sinh viên
        /// </summary>
        /// <param name="sv"> Hoàng Quốc Minh nè!! </param>
        /// <returns></returns>
        
        public bool suaSinhVien(DTO_SinhVien sv)
        {
            try
            {
                // Kết nối
                _conn.Open();
                // Query string
                string SQL = string.Format("UPDATE SINHVIEN SET SV_NAME = N'{0}', SV_PHONE = '{1}', SV_EMAIL = '{2}' WHERE SV_ID = {3}", sv.SINHVIEN_NAME, sv.SINHVIEN_PHONE, sv.SINHVIEN_EMAIL, sv.SINHVIEN_ID);

                SqlCommand cmd = new SqlCommand(SQL, _conn);
                // Query và kiểm tra
                if (cmd.ExecuteNonQuery() > 0)
                    return true;
            }
            catch (Exception e)
            {

            }
            finally
            {
                // Đóng kết nối
                _conn.Close();
            }

            return false;
        }

        /// <summary>
        /// Xóa Sinh viên
        /// </summary>
        /// <param name="sv"></param>
        /// <returns></returns>

        public bool xoaSinhVien(int SV_ID)
        {
            try
            {
                // Kết nối
                _conn.Open();
                // Query string - vì xóa chỉ cần ID nên không cần phải dùng DTO, chỉ cần ID là đủ
                string SQL = string.Format("DELETE FROM SINHVIEN WHERE SV_ID = {0}", SV_ID);

                SqlCommand cmd = new SqlCommand(SQL, _conn);
                // Query và kiểm tra
                if (cmd.ExecuteNonQuery() > 0)
                    return true;
            }
            catch (Exception e)
            {

            }
            finally
            {
                // Đóng kết nối
                _conn.Close();
            }

            return false;
        }

        public DataTable timSinhVien(string SV_NAME)
        {
            DataTable dtSearch = new DataTable();
            try
            {
                // Kết nối
                _conn.Open();

                //string SQL = string.Format("SELECT * FROM SINHVIEN WHERE SV_NAME LIKE N'%{0}%'", SV_NAME);
                string SQL = "SELECT * FROM SINHVIEN WHERE SV_NAME LIKE N'%Minh%'";

                SqlCommand cmd = new SqlCommand(SQL, _conn);

                Console.WriteLine(_conn.State);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dtSearch);
            }
            catch (Exception e)
            {

            }
            finally
            {
                // Đóng kết nối
                _conn.Close();
            }

            return dtSearch;
        }

        public DataTable GetSinhVienBy(Dictionary<string, string> filter)
        {
            StringBuilder sb = new StringBuilder("SELECT * FROM SINHVIEN");

            if (filter != null && filter.Count > 0)
            {
                sb.Append(" WHERE ");
            }


            foreach (KeyValuePair<string, string> entry in filter)
            {
                sb.AppendFormat("{0} LIKE N'%{1}%'", entry.Key, entry.Value);
                if (entry.Key.Equals(filter.Last().Key))
                {
                    sb.Append(";");
                }
                else
                {
                    sb.Append(" OR ");
                }
            }

            Console.WriteLine(sb.ToString());
            SqlDataAdapter da = new SqlDataAdapter(sb.ToString(), _conn);
            DataTable dt = new DataTable();
            da.Fill(dt);

            return dt;
        }
    }
}

